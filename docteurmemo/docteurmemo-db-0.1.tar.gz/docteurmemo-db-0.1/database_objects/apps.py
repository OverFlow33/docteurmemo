from django.apps import AppConfig


class DatabaseObjectsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'database_objects'
